import pygame

pygame.init()
# import pygame.mixer
#
# pygame.init()
# pygame.mixer.music.load("pixel-plains-158773 (1).mp3")#musica
# pygame.mixer.music.play(-1)pip ins
# click = pygame.mixer.Sound("pixel-plains-158773 (1).mp3")#efeito


# Dimensões dos quadrados
lado_quadrado = 80

# Posição inicial dos quadrados
x_inicio = 181
x_inicio2 = 265
x_inicio3 = 350
x_inicio4 = 433
x_inicio5 = 518
x_inicio6 = 602
x_inicio7 = 687
x_inicio8 = 772
x_inicio9 = 857
x_inicio10 = 940
x_inicio11 = 1025
x_inicio12 = 1108
x_inicio13 = 1195
x_inicio14 = 1280
x_inicio15 = 1364
x_inicio16 = 1447
x_inicio17 = 1532
x_inicio18 = 1618
# espaçamenntos horizontais
quadrados = []
clicou = []
# Defina a posição x para a coluna dos metais alcalinos
cor = []
for i in range(118):
    cor_elementos = "gray"
    cor.append(cor_elementos)

# Espaçamento entre quadrados
espacamento = 5
espacamento_y = 243
espacamento_y3 = 412


def siglas():
    for i in range(88):  # Total de 118 elementos
        font = pygame.font.SysFont(None, 20)  # Escolha a fonte aqui
        text = font.render(elementos[i], True, (0, 0, 0))  # Define a cor do texto aqui
        text_rect = text.get_rect(center=quadrados[i].center)
        janela.blit(text, text_rect)


y_inicio = 40


def metais_alcalino():
    for i in range(7):
        y_quadrado = i * 84.5 + espacamento + 153
        quadrado = pygame.Rect(x_inicio * escala_x, y_quadrado * escala_y, lado_quadrado * escala_x,
                               lado_quadrado * escala_y)
        pygame.draw.rect(janela, cor[i], quadrado)
        quadrados.append(quadrado)


def metais_alcalinos_terrosos():
    for i in range(6):
        y_quadrado2 = i * 84.5 + espacamento_y
        quadrado2 = pygame.Rect(x_inicio2 * escala_x, y_quadrado2 * escala_y, lado_quadrado * escala_x,
                                lado_quadrado * escala_y)
        pygame.draw.rect(janela, cor[i + 7], quadrado2)
        quadrados.append(quadrado2)


def grupo_3B():
    for i in range(2):
        y_quadrado3 = i * 84.5 + espacamento_y3
        quadrado3 = pygame.Rect(x_inicio3 * escala_x, y_quadrado3 * escala_y, lado_quadrado * escala_x,
                                lado_quadrado * escala_y)
        pygame.draw.rect(janela, cor[i + 7 + 6], quadrado3)
        quadrados.append(quadrado3)


def grupo_4B():
    for i in range(4):
        y_quadrado4 = i * 84.5 + espacamento_y3
        quadrado4 = pygame.Rect(x_inicio4 * escala_x, y_quadrado4 * escala_y, lado_quadrado * escala_x,
                                lado_quadrado * escala_y)
        pygame.draw.rect(janela, cor[i + 7 + 6 + 2], quadrado4)
        quadrados.append(quadrado4)


def grupo_5B():
    for i in range(4):
        y_quadrado5 = i * 84.5 + espacamento_y3
        quadrado5 = pygame.Rect(x_inicio5 * escala_x, y_quadrado5 * escala_y, lado_quadrado * escala_x,
                                lado_quadrado * escala_y)
        pygame.draw.rect(janela, cor[i + 7 + 6 + 2 + 4], quadrado5)
        quadrados.append(quadrado5)


def grupo_6B():
    for i in range(4):
        y_quadrado6 = i * 84.5 + espacamento_y3
        quadrado6 = pygame.Rect(x_inicio6 * escala_x, y_quadrado6 * escala_y, lado_quadrado * escala_x,
                                lado_quadrado * escala_y)
        pygame.draw.rect(janela, cor[i + 7 + 6 + 2 + 4 + 4], quadrado6)
        quadrados.append(quadrado6)


def grupo_7B():
    for i in range(4):
        y_quadrado7 = i * 84.5 + espacamento_y3
        quadrado7 = pygame.Rect(x_inicio7 * escala_x, y_quadrado7 * escala_y, lado_quadrado * escala_x,
                                lado_quadrado * escala_y)
        pygame.draw.rect(janela, cor[i + 7 + 6 + 2 + 4 + 4 + 4], quadrado7)
        quadrados.append(quadrado7)


def grupo_8B():
    for i in range(4):
        y_quadrado8 = i * 84.5 + espacamento_y3
        quadrado8 = pygame.Rect(x_inicio8 * escala_x, y_quadrado8 * escala_y, lado_quadrado * escala_x,
                                lado_quadrado * escala_y)
        pygame.draw.rect(janela, cor[i + 7 + 6 + 2 + 4 + 4 + 4 + 4], quadrado8)
        quadrados.append(quadrado8)


def grupo_9B():
    for i in range(4):
        y_quadrado9 = i * 84.5 + espacamento_y3
        quadrado9 = pygame.Rect(x_inicio9 * escala_x, y_quadrado9 * escala_y, lado_quadrado * escala_x,
                                lado_quadrado * escala_y)
        pygame.draw.rect(janela, cor[i + 7 + 6 + 2 + 4 + 4 + 4 + 4 + 4], quadrado9)
        quadrados.append(quadrado9)


def grupo_10B():
    for i in range(4):
        y_quadrado10 = i * 84.5 + espacamento_y3
        quadrado10 = pygame.Rect(x_inicio10 * escala_x, y_quadrado10 * escala_y, lado_quadrado * escala_x,
                                 lado_quadrado * escala_y)
        pygame.draw.rect(janela, cor[i + 7 + 6 + 2 + 4 + 4 + 4 + 4 + 4 + 4], quadrado10)
        quadrados.append(quadrado10)


def grupo_11B():
    for i in range(4):
        y_quadrado11 = i * 84.5 + espacamento_y3
        quadrado11 = pygame.Rect(x_inicio11 * escala_x, y_quadrado11 * escala_y, lado_quadrado * escala_x,
                                 lado_quadrado * escala_y)
        pygame.draw.rect(janela, cor[i + 7 + 6 + 2 + 4 + 4 + 4 + 4 + 4 + 4 + 4], quadrado11)
        quadrados.append(quadrado11)


def grupo_12B():
    for i in range(4):
        y_quadrado12 = i * 84.5 + espacamento_y3
        quadrado12 = pygame.Rect(x_inicio12 * escala_x, y_quadrado12 * escala_y, lado_quadrado * escala_x,
                                 lado_quadrado * escala_y)
        pygame.draw.rect(janela, cor[i + 7 + 6 + 2 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 4], quadrado12)
        quadrados.append(quadrado12)


def familia_do_Boro():
    for i in range(6):
        y_quadrado13 = i * 84.5 + espacamento_y
        quadrado13 = pygame.Rect(x_inicio13 * escala_x, y_quadrado13 * escala_y, lado_quadrado * escala_x,
                                 lado_quadrado * escala_y)
        pygame.draw.rect(janela, cor[i + 7 + 6 + 2 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 4], quadrado13)
        quadrados.append(quadrado13)


def familia_do_carbono():
    for i in range(6):
        y_quadrado14 = i * 84.5 + espacamento_y
        quadrado14 = pygame.Rect(x_inicio14 * escala_x, y_quadrado14 * escala_y, lado_quadrado * escala_x,
                                 lado_quadrado * escala_y)
        pygame.draw.rect(janela, cor[i + +7 + 6 + 2 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 6], quadrado14)
        quadrados.append(quadrado14)


def familia_do_nitrogenio():
    for i in range(6):
        y_quadrado15 = i * 84.5 + espacamento_y
        quadrado15 = pygame.Rect(x_inicio15 * escala_x, y_quadrado15 * escala_y, lado_quadrado * escala_x,
                                 lado_quadrado * escala_y)
        pygame.draw.rect(janela, cor[i + 7 + 6 + 2 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 6 + 6], quadrado15)
        quadrados.append(quadrado15)


def familia_do_oxigenio():
    for i in range(6):
        y_quadrado16 = i * 84.5 + espacamento_y
        quadrado16 = pygame.Rect(x_inicio16 * escala_x, y_quadrado16 * escala_y, lado_quadrado * escala_x,
                                 lado_quadrado * escala_y)
        pygame.draw.rect(janela, cor[i + 7 + 6 + 2 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 6 + 6 + 6], quadrado16)
        quadrados.append(quadrado16)


def familia_do_halogenios():
    for i in range(6):
        y_quadrado17 = i * 84.5 + espacamento_y
        quadrado17 = pygame.Rect(x_inicio17 * escala_x, y_quadrado17 * escala_y, lado_quadrado * escala_x,
                                 lado_quadrado * escala_y)
        pygame.draw.rect(janela, cor[i + 7 + 6 + 2 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 6 + 6 + 6 + 6], quadrado17)
        quadrados.append(quadrado17)


def gases_nobres():
    for i in range(7):
        y_quadrado18 = i * 84.5 + espacamento + 153
        quadrado18 = pygame.Rect(x_inicio18 * escala_x, y_quadrado18 * escala_y, lado_quadrado * escala_x,
                                 lado_quadrado * escala_y)
        pygame.draw.rect(janela, cor[i + 7 + 6 + 2 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 4 + 6 + 6 + 6 + 6 + 6], quadrado18)
        quadrados.append(quadrado18)


elementos = ["H", "Li", "Na", "K", "Rb", "Cs", "Fr", "Be", "Mg", "Ca", "Sr", "Ba", "Ra", "Sc", "Y", "Ti", "Zr",
             "Hf", "Rf", "V", "Nb", "Ta", "Db", "Cr", "Mo", "W", "Sg", "Mn", "Tc", "Re", "Bh", "Fe", "Ru", "Os", "Hs",
             "Co",
             "Rh", "Ir", "Mt", "Ni", "Pd", "Pt", "Ds", "Cu", "Ag", "Au", "Rg", "Zn", "Cd", "Hg", "Cn", "B", "Al", "Ga",
             "In",
             "Tl", "Nh", "C", "Si", "Ge", "Sn", "Pb", "Fl", "N", "P", "As", "Sb", "Bi", "Mc", "O", "S", "Se", "Te",
             "Po", "Lv", "F",
             "Cl", "Br", "I", "At", "Ts", "He", "Ne", "Ar", "Kr", "Xe", "Rn", "Og"]
resposta = ["Li", "Na", "K", "Rb", "Cs", "Fr"]

fonte = pygame.font.SysFont(None, 100)
fonte2 = pygame.font.SysFont(None, 120)
contador_acertos = 0
contador_erros = 0
texto2 = fonte.render(str(contador_acertos), True, "black")

tempo_inicial = 0
tick = 0
frame = 0
questao = False
botao_c = []


# Funcao que contem as coisas da janela inicial
def janela_inicial():
    global botao
    global botaoc
    global config_btc

    botao = pygame.draw.rect(janela, "#00BF63", config_bt, border_radius=90)

    botaoc = pygame.draw.rect(janela, "black", config_btc)
    janela.blit(redms, (0, 0))



def janela_cfg():
    global botao_casa
    global bt_credito
    global bt_tutorial
    global bt_sobre_o_jogo

    botao_casa = pygame.draw.rect(janela, "black", config_casa)

    bt_tutorial = pygame.draw.rect(janela, "black", config_tutorial, border_radius=90)
    bt_sobre_o_jogo = pygame.draw.rect(janela, "black", config_sobre_o_jogo, border_radius=90)
    janela.blit(redms_C, (0, 0))


# Funcao que contem as coisas da janela dimitri
def janela_dimitri():
    global config_seta
    global botao_dmt
    global botao_casa

    botao_dmt = pygame.draw.rect(janela, "#E6732D", config_seta)

    botao_casa = pygame.draw.rect(janela, "black", config_casa)
    janela.blit(redms_D, (0, 0))


# Funcao que contem as coisas da janela de fases
def janela_fases():
    global config_seta2
    global botao_seta2
    global botao_casa
    global botao_entrar

    botao_seta2 = pygame.draw.rect(janela, "Black", config_seta2)

    botao_entrar = pygame.draw.rect(janela, "black", config_entrar)
    botao_casa = pygame.draw.rect(janela, "black", config_casa, border_radius=100)
    janela.blit(redms_F, (0, 0))


# Funcao que contem as coisas da janela de fases2
def janela_fase2():
    global config_seta3
    global botao_casa
    global botao_seta3
    global botao_voltar2
    global botao_entrar

    botao_seta3 = pygame.draw.rect(janela, "black", config_seta3)

    botao_casa = pygame.draw.rect(janela, "black", config_casa, border_radius=100)

    botao_voltar2 = pygame.draw.rect(janela, "black", config_voltar)

    botao_entrar = pygame.draw.rect(janela, "black", config_entrar)
    janela.blit(redmsF2, (0, 0))


def janela_fase3():
    global botao_voltar
    global botao_casa

    botao_voltar = pygame.draw.rect(janela, "black", config_voltar)

    botao_casa = pygame.draw.rect(janela, "black", config_casa, border_radius=90)

    janela.blit(redmsF3, (0, 0))


def preparar():
    global botao_seta_preparar
    global botao_play
    botao_play = pygame.draw.rect(janela, "white", config_play)
    botao_seta_preparar = pygame.draw.rect(janela, "white", config_seta_preparar)
    janela.blit(redms_preparar, (0, 0))


def preparar2():
    global botao_seta_preparar
    global botao_play2
    botao_play2 = pygame.draw.rect(janela, "white", config_play2)
    botao_seta_preparar = pygame.draw.rect(janela, "white", config_seta_preparar)
    janela.blit(redms_preparar, (0, 0))


def preparar3():
    global botao_seta_preparar
    global botao_play3
    botao_play3 = pygame.draw.rect(janela, "white", config_play3)
    botao_seta_preparar = pygame.draw.rect(janela, "white", config_seta_preparar)
    janela.blit(redms_preparar, (0, 0))


def tres():
    janela.blit(redms_3, (0, 0))


def dois():
    janela.blit(redms_2, (0, 0))


def um():
    janela.blit(redms_1, (0, 0))


def go():
    janela.blit(redms_go, (0, 0))


def questao():
    global botao_proxima_questao2
    global frame_cronometro
    global tick_cronometro
    janela.blit(redms_questao, (0, 0))
    metais_alcalino()  # Desenha os quadrados
    metais_alcalinos_terrosos()
    grupo_3B()
    grupo_4B()
    grupo_5B()
    grupo_6B()
    grupo_7B()
    grupo_8B()
    grupo_9B()
    grupo_10B()
    grupo_11B()
    grupo_12B()
    familia_do_Boro()
    familia_do_carbono()
    familia_do_nitrogenio()
    familia_do_oxigenio()
    familia_do_halogenios()
    gases_nobres()
    siglas()
    tick_cronometro +=1
    if tick_cronometro == 4 and frame_cronometro != 20:
        frame_cronometro +=1
        tick_cronometro =0
    cronometro = fonte2.render(str(20 - frame_cronometro), True, "black")

    texto_acertos = fonte.render(str(contador_acertos), True, "black")
    janela.blit(texto_acertos, (90*escala_x, 40*escala_y))
    texto_erros = fonte.render(str(contador_erros), True, "black")
    janela.blit(texto_erros, (250*escala_x, 40*escala_y))
    janela.blit(cronometro, (1750*escala_x, 40*escala_y))
    if passar_questao:
        botao_proxima_questao2 = pygame.draw.polygon(janela, "#E6732D", [ponto1, ponto2, ponto3])


def questao3():
    global botao_proxima_questao2
    global frame_cronometro
    global tick_cronometro
    janela.blit(redms_questao3, (0, 0))
    metais_alcalino()  # Desenha os quadrados
    metais_alcalinos_terrosos()
    grupo_3B()
    grupo_4B()
    grupo_5B()
    grupo_6B()
    grupo_7B()
    grupo_8B()
    grupo_9B()
    grupo_10B()
    grupo_11B()
    grupo_12B()
    familia_do_Boro()
    familia_do_carbono()
    familia_do_nitrogenio()
    familia_do_oxigenio()
    familia_do_halogenios()
    gases_nobres()
    siglas()
    tick_cronometro +=1
    if tick_cronometro == 5 and frame_cronometro != 22:
        frame_cronometro +=1
        tick_cronometro =0
    cronometro = fonte2.render(str(22 - frame_cronometro), True, "black")
    texto_acertos = fonte.render(str(contador_acertos), True, "black")
    janela.blit(texto_acertos, (90*escala_x, 40*escala_y))
    texto_erros = fonte.render(str(contador_erros), True, "black")
    janela.blit(texto_erros, (250 * escala_x, 40 * escala_y))
    janela.blit(cronometro, (1750 * escala_x, 40 * escala_y))
    if passar_questao:
        botao_proxima_questao2 = pygame.draw.polygon(janela, "#E6732D", [ponto1, ponto2, ponto3])


def questao4():
    global botao_proxima_questao2
    global frame_cronometro
    global tick_cronometro
    janela.blit(redms_questao4, (0, 0))
    metais_alcalino()  # Desenha os quadrados
    metais_alcalinos_terrosos()
    grupo_3B()
    grupo_4B()
    grupo_5B()
    grupo_6B()
    grupo_7B()
    grupo_8B()
    grupo_9B()
    grupo_10B()
    grupo_11B()
    grupo_12B()
    familia_do_Boro()
    familia_do_carbono()
    familia_do_nitrogenio()
    familia_do_oxigenio()
    familia_do_halogenios()
    gases_nobres()
    siglas()
    tick_cronometro +=1
    if tick_cronometro == 5 and frame_cronometro != 22:
        frame_cronometro +=1
        tick_cronometro =0
    cronometro = fonte2.render(str(22 - frame_cronometro), True, "black")
    texto_acertos = fonte.render(str(contador_acertos), True, "black")
    janela.blit(texto_acertos, (90 * escala_x, 40 * escala_y))
    texto_erros = fonte.render(str(contador_erros), True, "black")
    janela.blit(texto_erros, (250 * escala_x, 40 * escala_y))
    janela.blit(cronometro, (1750 * escala_x, 40 * escala_y))
    if passar_questao:
        botao_proxima_questao2 = pygame.draw.polygon(janela, "#E6732D", [ponto1, ponto2, ponto3])


def questao5():
    global botao_final
    global tick_cronometro
    global frame_cronometro
    janela.blit(redms_questao5, (0, 0))
    metais_alcalino()  # Desenha os quadrados
    metais_alcalinos_terrosos()
    grupo_3B()
    grupo_4B()
    grupo_5B()
    grupo_6B()
    grupo_7B()
    grupo_8B()
    grupo_9B()
    grupo_10B()
    grupo_11B()
    grupo_12B()
    familia_do_Boro()
    familia_do_carbono()
    familia_do_nitrogenio()
    familia_do_oxigenio()
    familia_do_halogenios()
    gases_nobres()
    siglas()
    tick_cronometro +=1
    if tick_cronometro == 5 and frame_cronometro != 22:
        frame_cronometro +=1
        tick_cronometro =0
    cronometro = fonte2.render(str(22- frame_cronometro), True, "black")
    texto_acertos = fonte.render(str(contador_acertos), True, "black")
    janela.blit(texto_acertos, (90 * escala_x, 40 * escala_y))
    texto_erros = fonte.render(str(contador_erros), True, "black")
    janela.blit(texto_erros, (250 * escala_x, 40 * escala_y))
    janela.blit(cronometro, (1750 * escala_x, 40 * escala_y))
    if passar_questao:
        botao_proxima_questao2 = pygame.draw.polygon(janela, "#E6732D", [ponto1, ponto2, ponto3])


# def apressado():
#     janela.blit(img_apressadinho, (0, 0))


def erro():
    global botao_x
    botao_x = pygame.draw.rect(janela, "red", config_x)
    janela.blit(redms_erro, (0, 0))


def erro2():
    global botao_x2
    botao_x2 = pygame.draw.rect(janela, "red", config_x2)
    janela.blit(redms_erro2, (0, 0))


def credito():
    global botao_x3
    global seta_credito
    botao_x3 = pygame.draw.rect(janela, "red", config_x3)
    seta_credito = pygame.draw.rect(janela, "red", config_seta_credito)

    janela.blit(redms_credito, (0, 0))


def credito2():
    global botao_x4
    global seta_credito2

    seta_credito2 = pygame.draw.rect(janela, "red", config_seta_credito2)

    botao_x4 = pygame.draw.rect(janela, "red", config_x4)
    janela.blit(redms_credito2, (0, 0))


def questao2():
    global botao_proxima_questao2
    global frame_cronometro
    global tick_cronometro
    janela.blit(redms_questao2, (0, 0))
    metais_alcalino()  # Desenha os quadrados
    metais_alcalinos_terrosos()
    grupo_3B()
    grupo_4B()
    grupo_5B()
    grupo_6B()
    grupo_7B()
    grupo_8B()
    grupo_9B()
    grupo_10B()
    grupo_11B()
    grupo_12B()
    familia_do_Boro()
    familia_do_carbono()
    familia_do_nitrogenio()
    familia_do_oxigenio()
    familia_do_halogenios()
    gases_nobres()
    siglas()
    tick_cronometro +=1
    if tick_cronometro == 5 and frame_cronometro != 22:
        frame_cronometro +=1
        tick_cronometro =0
    cronometro = fonte.render(str(22 - frame_cronometro), True, "black")
    texto_acertos = fonte.render(str(contador_acertos), True, "black")
    janela.blit(texto_acertos, (90 * escala_x, 40 * escala_y))
    texto_erros = fonte.render(str(contador_erros), True, "black")
    janela.blit(texto_erros, (250 * escala_x, 40 * escala_y))
    janela.blit(cronometro, (1750 * escala_x, 40 * escala_y))

    if passar_questao:
        botao_proxima_questao2 = pygame.draw.polygon(janela, "#E6732D", [ponto1, ponto2, ponto3])


def acerto():
    global botao_fase_dsbq
    botao_fase_dsbq = pygame.draw.rect(janela, "black", config_fase_dsbq, border_radius=100)
    janela.blit(redms_parabens, (0, 0))
    texto_acertos1 = fonte.render(str(contador_acertos), True, "#00BF63")
    janela.blit(texto_acertos1, (120*escala_x, 970*escala_y))
    texto_erros1 = fonte.render(str(contador_erros), True, "#FF3131")  # FF3131
    janela.blit(texto_erros1, (300*escala_x, 970*escala_y))


def errada():
    global botao_refazer
    botao_refazer = pygame.draw.rect(janela, "black", config_refazer, border_radius=100)
    janela.blit(redms_perdeu, (0, 0))
    texto_acertos1 = fonte.render(str(contador_acertos), True, "#00BF63")
    janela.blit(texto_acertos1, (120 * escala_x, 970 * escala_y))
    texto_erros1 = fonte.render(str(contador_erros), True, "#FF3131")  # FF3131
    janela.blit(texto_erros1, (300 * escala_x, 970 * escala_y))


def tutorial():
    global bt_seta_tutorial
    global bt_x5

    bt_seta_tutorial = pygame.draw.rect(janela, "black", config_seta_tutorial)
    bt_x5 = pygame.draw.rect(janela, "black", config_bt_x5)

    janela.blit(redms_tutorial, (0, 0))


def tutorial2():
    global bt_seta_tutorial2
    global bt_x6

    bt_seta_tutorial2 = pygame.draw.rect(janela, "black", config_seta_tutorial2)
    bt_x6 = pygame.draw.rect(janela, "black", config_x6)
    janela.blit(redms_tutorial2, (0, 0))


def sobre_o_jogo():
    global bt_x7
    bt_x7 = pygame.draw.rect(janela, "black", config_x7)

    janela.blit(redms_sobre_o_jogo, (0, 0))


def questao1_fase2():
    global botao_proxima_questao2
    global frame_cronometro
    global tick_cronometro
    janela.blit(redms_questao1_F2, (0, 0))
    metais_alcalino()  # Desenha os quadrados
    metais_alcalinos_terrosos()
    grupo_3B()
    grupo_4B()
    grupo_5B()
    grupo_6B()
    grupo_7B()
    grupo_8B()
    grupo_9B()
    grupo_10B()
    grupo_11B()
    grupo_12B()
    familia_do_Boro()
    familia_do_carbono()
    familia_do_nitrogenio()
    familia_do_oxigenio()
    familia_do_halogenios()
    gases_nobres()
    siglas()
    tick_cronometro +=1
    if tick_cronometro == 4 and frame_cronometro != 20:
        frame_cronometro +=1
        tick_cronometro =0
    cronometro = fonte2.render(str(20 - frame_cronometro), True, "black")
    texto_acertos = fonte.render(str(contador_acertos), True, "black")
    janela.blit(texto_acertos, (90 * escala_x, 40 * escala_y))
    texto_erros = fonte.render(str(contador_erros), True, "black")
    janela.blit(texto_erros, (250 * escala_x, 40 * escala_y))
    janela.blit(cronometro, (1750 * escala_x, 40 * escala_y))

    if passar_questao:
        botao_proxima_questao2 = pygame.draw.polygon(janela, "#E6732D", [ponto1, ponto2, ponto3])


def questao2_fase2():
    global botao_proxima_questao2
    global frame_cronometro
    global tick_cronometro
    janela.blit(redms_questao2_F2, (0, 0))
    metais_alcalino()  # Desenha os quadrados
    metais_alcalinos_terrosos()
    grupo_3B()
    grupo_4B()
    grupo_5B()
    grupo_6B()
    grupo_7B()
    grupo_8B()
    grupo_9B()
    grupo_10B()
    grupo_11B()
    grupo_12B()
    familia_do_Boro()
    familia_do_carbono()
    familia_do_nitrogenio()
    familia_do_oxigenio()
    familia_do_halogenios()
    gases_nobres()
    siglas()
    tick_cronometro +=1
    if tick_cronometro == 5 and frame_cronometro != 22:
        frame_cronometro +=1
        tick_cronometro =0
    cronometro = fonte2.render(str(22 - frame_cronometro), True, "black")
    texto_acertos = fonte.render(str(contador_acertos), True, "black")
    janela.blit(texto_acertos, (90 * escala_x, 40 * escala_y))
    texto_erros = fonte.render(str(contador_erros), True, "black")
    janela.blit(texto_erros, (250 * escala_x, 40 * escala_y))
    janela.blit(cronometro, (1750 * escala_x, 40 * escala_y))

    if passar_questao:
        botao_proxima_questao2 = pygame.draw.polygon(janela, "#E6732D", [ponto1, ponto2, ponto3])


def questao3_fase2():
    global botao_proxima_questao2
    global frame_cronometro
    global tick_cronometro
    janela.blit(redms_questao3_F2, (0, 0))
    metais_alcalino()  # Desenha os quadrados
    metais_alcalinos_terrosos()
    grupo_3B()
    grupo_4B()
    grupo_5B()
    grupo_6B()
    grupo_7B()
    grupo_8B()
    grupo_9B()
    grupo_10B()
    grupo_11B()
    grupo_12B()
    familia_do_Boro()
    familia_do_carbono()
    familia_do_nitrogenio()
    familia_do_oxigenio()
    familia_do_halogenios()
    gases_nobres()
    siglas()
    tick_cronometro +=1
    if tick_cronometro == 5 and frame_cronometro != 22:
        frame_cronometro +=1
        tick_cronometro =0
    cronometro = fonte2.render(str(22 - frame_cronometro), True, "black")
    texto_acertos = fonte.render(str(contador_acertos), True, "black")
    janela.blit(texto_acertos, (90 * escala_x, 40 * escala_y))
    texto_erros = fonte.render(str(contador_erros), True, "black")
    janela.blit(texto_erros, (250 * escala_x, 40 * escala_y))
    janela.blit(cronometro, (1750 * escala_x, 40 * escala_y))

    if passar_questao:
        botao_proxima_questao2 = pygame.draw.polygon(janela, "#E6732D", [ponto1, ponto2, ponto3])


def questao4_fase2():
    global botao_proxima_questao2
    global frame_cronometro
    global tick_cronometro
    janela.blit(redms_questao4_F2, (0, 0))
    metais_alcalino()  # Desenha os quadrados
    metais_alcalinos_terrosos()
    grupo_3B()
    grupo_4B()
    grupo_5B()
    grupo_6B()
    grupo_7B()
    grupo_8B()
    grupo_9B()
    grupo_10B()
    grupo_11B()
    grupo_12B()
    familia_do_Boro()
    familia_do_carbono()
    familia_do_nitrogenio()
    familia_do_oxigenio()
    familia_do_halogenios()
    gases_nobres()
    siglas()
    tick_cronometro +=1
    if tick_cronometro == 5 and frame_cronometro != 22:
        frame_cronometro +=1
        tick_cronometro =0
    cronometro = fonte2.render(str(22 - frame_cronometro), True, "black")
    texto_acertos = fonte.render(str(contador_acertos), True, "black")
    janela.blit(texto_acertos, (90 * escala_x, 40 * escala_y))
    texto_erros = fonte.render(str(contador_erros), True, "black")
    janela.blit(texto_erros, (250 * escala_x, 40 * escala_y))
    janela.blit(cronometro, (1750 * escala_x, 40 * escala_y))

    if passar_questao:
        botao_proxima_questao2 = pygame.draw.polygon(janela, "#E6732D", [ponto1, ponto2, ponto3])


def questao5_fase2():
    global botao_proxima_questao2
    global frame_cronometro
    global tick_cronometro
    janela.blit(redms_questao5_F2, (0, 0))
    metais_alcalino()  # Desenha os quadrados
    metais_alcalinos_terrosos()
    grupo_3B()
    grupo_4B()
    grupo_5B()
    grupo_6B()
    grupo_7B()
    grupo_8B()
    grupo_9B()
    grupo_10B()
    grupo_11B()
    grupo_12B()
    familia_do_Boro()
    familia_do_carbono()
    familia_do_nitrogenio()
    familia_do_oxigenio()
    familia_do_halogenios()
    gases_nobres()
    siglas()
    tick_cronometro +=1
    if tick_cronometro == 5 and frame_cronometro != 22:
        frame_cronometro +=1
        tick_cronometro =0
    cronometro = fonte2.render(str(22 - frame_cronometro), True, "black")
    texto_acertos = fonte.render(str(contador_acertos), True, "black")
    janela.blit(texto_acertos, (90 * escala_x, 40 * escala_y))
    texto_erros = fonte.render(str(contador_erros), True, "black")
    janela.blit(texto_erros, (250 * escala_x, 40 * escala_y))
    janela.blit(cronometro, (1750 * escala_x, 40 * escala_y))

    if passar_questao:
        botao_proxima_questao2 = pygame.draw.polygon(janela, "#E6732D", [ponto1, ponto2, ponto3])


def questao1_fase3():
    global botao_proxima_questao2
    global tick_cronometro
    global frame_cronometro
    janela.blit(redms_questao1_F3, (0, 0))
    metais_alcalino()  # Desenha os quadrados
    metais_alcalinos_terrosos()
    grupo_3B()
    grupo_4B()
    grupo_5B()
    grupo_6B()
    grupo_7B()
    grupo_8B()
    grupo_9B()
    grupo_10B()
    grupo_11B()
    grupo_12B()
    familia_do_Boro()
    familia_do_carbono()
    familia_do_nitrogenio()
    familia_do_oxigenio()
    familia_do_halogenios()
    gases_nobres()
    siglas()
    tick_cronometro +=1
    if tick_cronometro == 4 and frame_cronometro != 20:
        frame_cronometro +=1
        tick_cronometro =0
    cronometro = fonte2.render(str(20 - frame_cronometro), True, "black")
    texto_acertos = fonte.render(str(contador_acertos), True, "black")
    janela.blit(texto_acertos, (90 * escala_x, 40 * escala_y))
    texto_erros = fonte.render(str(contador_erros), True, "black")
    janela.blit(texto_erros, (250 * escala_x, 40 * escala_y))
    janela.blit(cronometro, (1750 * escala_x, 40 * escala_y))
    if passar_questao:
        botao_proxima_questao2 = pygame.draw.polygon(janela, "#E6732D", [ponto1, ponto2, ponto3])


def questao2_fase3():
    global botao_proxima_questao3
    global tick_cronometro
    global frame_cronometro
    janela.blit(redms_questao2_F3, (0, 0))
    metais_alcalino()  # Desenha os quadrados
    metais_alcalinos_terrosos()
    grupo_3B()
    grupo_4B()
    grupo_5B()
    grupo_6B()
    grupo_7B()
    grupo_8B()
    grupo_9B()
    grupo_10B()
    grupo_11B()
    grupo_12B()
    familia_do_Boro()
    familia_do_carbono()
    familia_do_nitrogenio()
    familia_do_oxigenio()
    familia_do_halogenios()
    gases_nobres()
    siglas()
    tick_cronometro +=1
    if tick_cronometro == 5 and frame_cronometro != 22:
        frame_cronometro +=1
        tick_cronometro =0
    cronometro = fonte2.render(str(22 - frame_cronometro), True, "black")
    texto_acertos = fonte.render(str(contador_acertos), True, "black")
    janela.blit(texto_acertos, (90 * escala_x, 40 * escala_y))
    texto_erros = fonte.render(str(contador_erros), True, "black")
    janela.blit(texto_erros, (250 * escala_x, 40 * escala_y))
    janela.blit(cronometro, (1750 * escala_x, 40 * escala_y))

    if passar_questao:
        botao_proxima_questao2 = pygame.draw.polygon(janela, "#E6732D", [ponto1, ponto2, ponto3])

def questao3_fase3():
    global botao_proxima_questao3
    global tick_cronometro
    global frame_cronometro
    janela.blit(redms_questao3_F3, (0, 0))
    metais_alcalino()  # Desenha os quadrados
    metais_alcalinos_terrosos()
    grupo_3B()
    grupo_4B()
    grupo_5B()
    grupo_6B()
    grupo_7B()
    grupo_8B()
    grupo_9B()
    grupo_10B()
    grupo_11B()
    grupo_12B()
    familia_do_Boro()
    familia_do_carbono()
    familia_do_nitrogenio()
    familia_do_oxigenio()
    familia_do_halogenios()
    gases_nobres()
    siglas()
    tick_cronometro +=1
    if tick_cronometro == 5 and frame_cronometro != 22:
        frame_cronometro +=1
        tick_cronometro =0
    cronometro = fonte2.render(str(22 - frame_cronometro), True, "black")
    texto_acertos = fonte.render(str(contador_acertos), True, "black")
    janela.blit(texto_acertos, (90 * escala_x, 40 * escala_y))
    texto_erros = fonte.render(str(contador_erros), True, "black")
    janela.blit(texto_erros, (250 * escala_x, 40 * escala_y))
    janela.blit(cronometro, (1750 * escala_x, 40 * escala_y))

    if passar_questao:
        botao_proxima_questao2 = pygame.draw.polygon(janela, "#E6732D", [ponto1, ponto2, ponto3])


def questao4_fase3():
    global botao_proxima_questao3
    global tick_cronometro
    global frame_cronometro
    janela.blit(redms_questao4_F3, (0, 0))
    metais_alcalino()  # Desenha os quadrados
    metais_alcalinos_terrosos()
    grupo_3B()
    grupo_4B()
    grupo_5B()
    grupo_6B()
    grupo_7B()
    grupo_8B()
    grupo_9B()
    grupo_10B()
    grupo_11B()
    grupo_12B()
    familia_do_Boro()
    familia_do_carbono()
    familia_do_nitrogenio()
    familia_do_oxigenio()
    familia_do_halogenios()
    gases_nobres()
    siglas()
    tick_cronometro +=1
    if tick_cronometro == 5 and frame_cronometro != 22:
        frame_cronometro +=1
        tick_cronometro =0
    cronometro = fonte2.render(str(22 - frame_cronometro), True, "black")
    texto_acertos = fonte.render(str(contador_acertos), True, "black")
    janela.blit(texto_acertos, (90 * escala_x, 40 * escala_y))
    texto_erros = fonte.render(str(contador_erros), True, "black")
    janela.blit(texto_erros, (250 * escala_x, 40 * escala_y))
    janela.blit(cronometro, (1750 * escala_x, 40 * escala_y))

    if passar_questao:
        botao_proxima_questao2 = pygame.draw.polygon(janela, "#E6732D", [ponto1, ponto2, ponto3])


def questao5_fase3():
    global botao_proxima_questao3
    global tick_cronometro
    global frame_cronometro
    janela.blit(redms_questao5_F3, (0, 0))
    metais_alcalino()  # Desenha os quadrados
    metais_alcalinos_terrosos()
    grupo_3B()
    grupo_4B()
    grupo_5B()
    grupo_6B()
    grupo_7B()
    grupo_8B()
    grupo_9B()
    grupo_10B()
    grupo_11B()
    grupo_12B()
    familia_do_Boro()
    familia_do_carbono()
    familia_do_nitrogenio()
    familia_do_oxigenio()
    familia_do_halogenios()
    gases_nobres()
    siglas()
    tick_cronometro +=1
    if tick_cronometro == 5 and frame_cronometro != 22:
        frame_cronometro +=1
        tick_cronometro =0
    cronometro = fonte2.render(str(22 - frame_cronometro), True, "black")
    texto_acertos = fonte.render(str(contador_acertos), True, "black")
    janela.blit(texto_acertos, (90 * escala_x, 40 * escala_y))
    texto_erros = fonte.render(str(contador_erros), True, "black")
    janela.blit(texto_erros, (250 * escala_x, 40 * escala_y))
    janela.blit(cronometro, (1750 * escala_x, 40 * escala_y))

    if passar_questao:
        botao_proxima_questao2 = pygame.draw.polygon(janela, "#E6732D", [ponto1, ponto2, ponto3])


# janela e dimensoes
info = pygame.display.Info()
largura = info.current_w
altura = info.current_h
janela = pygame.display.set_mode((largura, altura))
escala_x = largura / 1920
escala_y = altura / 1080
# imagens de fundo/janela/redms
# IMG/janela INICIAL
img = pygame.image.load("QUIZ PERIÓDICO/1.png")
redms = pygame.transform.scale(img, (largura, altura))

img_config = pygame.image.load("QUIZ PERIÓDICO/2.png")
redms_C = pygame.transform.scale(img_config, (largura, altura))

janela_credito = pygame.image.load("QUIZ PERIÓDICO/4.png")
redms_credito = pygame.transform.scale(janela_credito, (largura, altura))

janela_credito2 = pygame.image.load("QUIZ PERIÓDICO/5.png")
redms_credito2 = pygame.transform.scale(janela_credito2, (largura, altura))

img_sobre_o_jogo = pygame.image.load("QUIZ PERIÓDICO/3.png")
redms_sobre_o_jogo = pygame.transform.scale(img_sobre_o_jogo, (largura, altura))


#_________________imagens dimitri_________________
img_dimitri = pygame.image.load("QUIZ PERIÓDICO/6.png")
redms_D = pygame.transform.scale(img_dimitri, (largura, altura))




#____________________________FASES________________
img_fases = pygame.image.load("QUIZ PERIÓDICO/7.png")
redms_F = pygame.transform.scale(img_fases, (largura, altura))

img_fase2 = pygame.image.load("QUIZ PERIÓDICO/8.png")
redmsF2 = pygame.transform.scale(img_fase2, (largura, altura))

janela_erro = pygame.image.load("QUIZ PERIÓDICO/9.png")
redms_erro = pygame.transform.scale(janela_erro, (largura, altura))

img_fase3 = pygame.image.load("QUIZ PERIÓDICO/10.png")
redmsF3 = pygame.transform.scale(img_fase3, (largura, altura))

janela_erro2 = pygame.image.load("QUIZ PERIÓDICO/11.png")
redms_erro2 = pygame.transform.scale(janela_erro2, (largura, altura))

img_fase2dsbq = pygame.image.load("QUIZ PERIÓDICO/12.png")
redms_fase2dsbq = pygame.transform.scale(img_fase2dsbq, (largura, altura))


#_________________________preparar e contagem e regressiva_______________
img_preparar = pygame.image.load("QUIZ PERIÓDICO/14.png")
redms_preparar = pygame.transform.scale(img_preparar, (largura, altura))

img_3 = pygame.image.load("QUIZ PERIÓDICO/15.png")
redms_3 = pygame.transform.scale(img_3, (largura, altura))

img_2 = pygame.image.load("QUIZ PERIÓDICO/16.png")
redms_2 = pygame.transform.scale(img_2, (largura, altura))

img_1 = pygame.image.load("QUIZ PERIÓDICO/17.png")
redms_1 = pygame.transform.scale(img_1, (largura, altura))

img_go = pygame.image.load("QUIZ PERIÓDICO/18.png")
redms_go = pygame.transform.scale(img_go, (largura, altura))


#_________________________parabens,perdeu,zerou_______________
img_parabens = pygame.image.load("QUIZ PERIÓDICO/20.png")
redms_parabens = pygame.transform.scale(img_parabens, (largura, altura))


img_perdeu = pygame.image.load("QUIZ PERIÓDICO/19.png")
redms_perdeu = pygame.transform.scale(img_perdeu, (largura, altura))

# img_zerou= pygame.image.load("QUIZ PERIÓDICO/21.png")
# redms_perdeu = pygame.transform.scale(img_zerou, (largura, altura))
#_________________________questoes fase 1________________________

img_questao = pygame.image.load("PERGUNTAS FASE 1 ( GRUPOS E PERÍODOS )/1.png")
redms_questao = pygame.transform.scale(img_questao, (largura, altura))

img_questao2 = pygame.image.load("PERGUNTAS FASE 1 ( GRUPOS E PERÍODOS )/2.png")
redms_questao2 = pygame.transform.scale(img_questao2, (largura, altura))

img_questao3 = pygame.image.load("PERGUNTAS FASE 1 ( GRUPOS E PERÍODOS )/3.png")
redms_questao3 = pygame.transform.scale(img_questao3, (largura, altura))

img_questao4 = pygame.image.load("PERGUNTAS FASE 1 ( GRUPOS E PERÍODOS )/4.png")
redms_questao4 = pygame.transform.scale(img_questao4, (largura, altura))

img_questao5 = pygame.image.load("PERGUNTAS FASE 1 ( GRUPOS E PERÍODOS )/5.png")
redms_questao5 = pygame.transform.scale(img_questao5, (largura, altura))

# img_questao6 = pygame.image.load("PERGUNTAS FASE 1 ( GRUPOS E PERÍODOS )/5.png")
# redms_questao6 = pygame.transform.scale(img_questao6, (largura, altura))
#
# img_questao7 = pygame.image.load("PERGUNTAS FASE 1 ( GRUPOS E PERÍODOS )/5.png")
# redms_questao7 = pygame.transform.scale(img_questao7, (largura, altura))

#------------------------------------FASE 2-------------------

img_questao1_F2 = pygame.image.load("_PERGUNTAS FASE 2  ( PROPRIEDADES )/1.png")
redms_questao1_F2 = pygame.transform.scale(img_questao1_F2, (largura, altura))

img_questao2_F2 = pygame.image.load("_PERGUNTAS FASE 2  ( PROPRIEDADES )/2.png")
redms_questao2_F2 = pygame.transform.scale(img_questao2_F2, (largura, altura))

img_questao3_F2 = pygame.image.load("_PERGUNTAS FASE 2  ( PROPRIEDADES )/3.png")
redms_questao3_F2 = pygame.transform.scale(img_questao3_F2, (largura, altura))

img_questao4_F2 = pygame.image.load("_PERGUNTAS FASE 2  ( PROPRIEDADES )/4.png")
redms_questao4_F2 = pygame.transform.scale(img_questao4_F2, (largura, altura))

img_questao5_F2 = pygame.image.load("_PERGUNTAS FASE 2  ( PROPRIEDADES )/5.png")
redms_questao5_F2 = pygame.transform.scale(img_questao5_F2, (largura, altura))

#------------------------------------FASE 3-------------------

img_questao1_F3 = pygame.image.load("PERGUNTAS FASE 3  ( DISTRIBUIÇÃO ELETRÔNICA )/1.png")
redms_questao1_F3 = pygame.transform.scale(img_questao1_F3, (largura, altura))

img_questao2_F3 = pygame.image.load("PERGUNTAS FASE 3  ( DISTRIBUIÇÃO ELETRÔNICA )/2.png")
redms_questao2_F3 = pygame.transform.scale(img_questao2_F3, (largura, altura))

img_questao3_F3 = pygame.image.load("PERGUNTAS FASE 3  ( DISTRIBUIÇÃO ELETRÔNICA )/3.png")
redms_questao3_F3 = pygame.transform.scale(img_questao3_F3, (largura, altura))

img_questao4_F3 = pygame.image.load("PERGUNTAS FASE 3  ( DISTRIBUIÇÃO ELETRÔNICA )/4.png")
redms_questao4_F3 = pygame.transform.scale(img_questao4_F3, (largura, altura))

img_questao5_F3 = pygame.image.load("PERGUNTAS FASE 3  ( DISTRIBUIÇÃO ELETRÔNICA )/5.png")
redms_questao5_F3 = pygame.transform.scale(img_questao5_F3, (largura, altura))






#++++++++++++++++++imgs tutoriais++++++++++++++++++++
img_tutorial = pygame.image.load("TELA TURORIAL/1.png")
redms_tutorial = pygame.transform.scale(img_tutorial, (largura, altura))

img_tutorial2 = pygame.image.load("TELA TURORIAL/2.png")
redms_tutorial2 = pygame.transform.scale(img_tutorial2, (largura, altura))










# variaveis que contam
contagem = 0

# configs botoes  ========================================
config_bt = pygame.Rect(840 * escala_x, 700 * escala_x, 290 * escala_x, 130 * escala_y)

config_btc = pygame.Rect(20 * escala_x, 980 * escala_y, 80 * escala_x, 80 * escala_y)

config_casa = pygame.Rect(25 * escala_x, 25 * escala_y, 150 * escala_x, 150 * escala_y)

config_seta = pygame.Rect(1800 * escala_x, 950 * escala_y, 100 * escala_x, 100 * escala_y)

config_seta2 = pygame.Rect(1400 * escala_x, 600 * escala_y, 150 * escala_x, 100 * escala_y)

config_seta3 = pygame.Rect(1400 * escala_x, 600 * escala_y, 150 * escala_x, 100 * escala_y)

config_voltar = pygame.Rect(400 * escala_x, 600 * escala_y, 150 * escala_x, 100 * escala_y)

config_voltar2 = pygame.Rect(400 * escala_x, 600 * escala_y, 150 * escala_x, 100 * escala_y)

config_entrar = pygame.Rect(650 * escala_x, 310 * escala_y, 700 * escala_x, 700 * escala_y)

config_play = pygame.Rect(850 * escala_x, 500 * escala_y, 260 * escala_x, 260 * escala_y)

config_play2 = pygame.Rect(850 * escala_x, 500 * escala_y, 260 * escala_x, 260 * escala_y)

config_play3 = pygame.Rect(850 * escala_x, 500 * escala_y, 260 * escala_x, 260 * escala_y)

config_seta_preparar = pygame.Rect(30 * escala_x, 950 * escala_y, 100 * escala_x, 100 * escala_y)

config_x = pygame.Rect(1400 * escala_x, 300 * escala_y, 70 * escala_x, 70 * escala_y)
config_x2 = pygame.Rect(1400 * escala_x, 300 * escala_y, 70 * escala_x, 70 * escala_y)

config_apressadinho = (200 * escala_x, 200 * escala_y, 200 * escala_x, 200 * escala_y)

config_credito = pygame.Rect(700 * escala_x, 640 * escala_y, 530 * escala_x, 150 * escala_y)

config_tutorial = pygame.Rect(700 * escala_x, 460 * escala_y, 530 * escala_x, 150 * escala_y)

config_x3 = pygame.Rect(1700 * escala_x, 100 * escala_y, 70 * escala_x, 70 * escala_y)

config_x4 = pygame.Rect(1700 * escala_x, 100 * escala_y, 70 * escala_x, 70 * escala_y)

config_bt_x5 = pygame.Rect(1780 * escala_x, 40 * escala_y, 70 * escala_x, 70 * escala_y)

config_x6 = pygame.Rect(1780 * escala_x, 40 * escala_y, 70 * escala_x, 70 * escala_y)

config_x7 = pygame.Rect(1700 * escala_x, 100 * escala_y, 70 * escala_x, 70 * escala_y)

config_seta_credito = pygame.Rect(1710 * escala_x, 515 * escala_y, 70 * escala_x, 70 * escala_y)

config_seta_questao2 = pygame.Rect(1800 * escala_x, 950 * escala_y, 200 * escala_x, 150 * escala_y)

ponto1 = (1900*escala_x,1000*escala_y)
ponto2 = (1780*escala_x,960*escala_y)
ponto3 = (1780*escala_x,1040*escala_y)
config_refazer = pygame.Rect(1750 * escala_x, 930 * escala_y, 150 * escala_x, 150 * escala_y)

config_fase_dsbq = pygame.Rect(1750 * escala_x, 930 * escala_y, 150 * escala_x, 150 * escala_y)

config_seta_credito2 = pygame.Rect(160 * escala_x, 540 * escala_y, 70 * escala_x, 70 * escala_y)

config_seta_tutorial = pygame.Rect(1710 * escala_x, 520 * escala_y, 70 * escala_x, 70 * escala_y)

config_seta_tutorial = pygame.Rect(1710 * escala_x, 520 * escala_y, 70 * escala_x, 70 * escala_y)

config_seta_tutorial2 = pygame.Rect(60 * escala_x, 520 * escala_y, 70 * escala_x, 70 * escala_y)

config_sobre_o_jogo = pygame.Rect(560 * escala_x, 260 * escala_y, 830 * escala_x, 150 * escala_y)

# LOOP
abrir = True
janela1 = True
janela2 = False
janela3 = False
janela4 = False
janela5 = False
janela_configuracoes = False
janela_preparar = False
janela_preparar2 = False
janela_preparar3 = False
janela_contagem3 = False
janela_contagem4 = False
janela_contagem5 = False
mensagem = False
janela_go = False
img_erro = False
img_erro2 = False
janela_credito = False
janela_credito2 = False
janela_questao = False
janela_questao2 = False
janela_questao3 = False
janela_questao4 = False
janela_questao5 = False
janela_questao1_fase2 = False
janela_questao2_fase2 = False
janela_questao3_fase2 = False
janela_questao4_fase2 = False
janela_questao5_fase2 = False
janela_questao1_fase3 = False
janela_questao2_fase3 = False
janela_questao3_fase3 = False
janela_questao4_fase3 = False
janela_questao5_fase3 = False
pega_tempo_inicial = False
muda_contador = False
passar_questao = False
passar_questao3 = False
janela_parabens = False
janela_perdeu = False
janela_tutorial = False
janela_tutorial2 = False
janela_sobre_o_jogo = False
dsbq_fase2 = False
fase2 = False
dsbq_fase3 = False
fase3 = False
fase_anterior=0
frame_cronometro = 0
tick_cronometro = 0
fps = pygame.time.Clock()

while abrir:
    fps.tick(10)
    tempo_atual = pygame.time.get_ticks()

    # Chamando as Funcoes
    if janela1:
        janela_inicial()
    elif janela2:
        janela_dimitri()
    elif janela3:
        janela_fases()
    elif janela4:
        janela_fase2()
    elif janela5:
        janela_fase3()
    elif janela_configuracoes:
        janela_cfg()
    elif janela_preparar:
        preparar()
    elif janela_preparar2:
        preparar2()

    elif img_erro:
        erro()
    elif img_erro2:
        erro2()
    elif janela_contagem3:
        while contagem < 4:
            janela.blit(redms_3, (0, 0))
            pygame.display.update()
            pygame.time.wait(1000)
            contagem += 1

            janela.blit(redms_2, (0, 0))
            pygame.display.update()
            pygame.time.wait(1000)
            contagem += 1

            janela.blit(redms_1, (0, 0))
            pygame.display.update()
            pygame.time.wait(1000)
            contagem += 1

            janela.blit(redms_go, (0, 0))
            pygame.display.update()
            pygame.time.wait(1000)
            contagem += 1
            tick_cronometro = 0
            frame_cronometro = 0

        questao()
        janela_questao = True
        if not pega_tempo_inicial:
            tempo_inicial = pygame.time.get_ticks()
            pega_tempo_inicial = True

    elif janela_contagem4:
        while contagem < 4:
            janela.blit(redms_3, (0, 0))
            pygame.display.update()
            pygame.time.wait(1000)
            contagem += 1

            janela.blit(redms_2, (0, 0))
            pygame.display.update()
            pygame.time.wait(1000)
            contagem += 1

            janela.blit(redms_1, (0, 0))
            pygame.display.update()
            pygame.time.wait(1000)
            contagem += 1

            janela.blit(redms_go, (0, 0))
            pygame.display.update()
            pygame.time.wait(1000)
            contagem += 1

        questao1_fase2()
        janela_questao1_fase2 = True


        if not pega_tempo_inicial:
            tempo_inicial = pygame.time.get_ticks()
            pega_tempo_inicial = True

    elif janela_contagem5:
        while contagem < 4:
            janela.blit(redms_3, (0, 0))
            pygame.display.update()
            pygame.time.wait(1000)
            contagem += 1

            janela.blit(redms_2, (0, 0))
            pygame.display.update()
            pygame.time.wait(1000)
            contagem += 1

            janela.blit(redms_1, (0, 0))
            pygame.display.update()
            pygame.time.wait(1000)
            contagem += 1

            janela.blit(redms_go, (0, 0))
            pygame.display.update()
            pygame.time.wait(1000)
            contagem += 1

        questao1_fase3()
        janela_questao1_fase3 = True
        if not pega_tempo_inicial:
            tempo_inicial = pygame.time.get_ticks()
            pega_tempo_inicial = True



    elif janela_credito:
        credito()

    elif janela_credito2:
        credito2()



    elif janela_go:
        go()
    # if mensagem:
    #     apressado()
    if janela_questao2:
        questao2()

    if janela_questao3:
        questao3()

    if janela_questao4:
        questao4()

    if janela_questao5:
        questao5()

    if janela_questao2_fase2:
        questao2_fase2()

    if janela_questao3_fase2:
        questao3_fase2()

    if janela_questao4_fase2:
        questao4_fase2()

    if janela_questao5_fase2:
        questao5_fase2()
    if janela_questao2_fase3:
        questao2_fase3()

    if janela_questao3_fase3:
        questao3_fase3()

    if janela_questao4_fase3:
        questao4_fase3()

    if janela_questao5_fase3:
        questao5_fase3()

    if janela_parabens:
        acerto()
    if janela_perdeu:
        errada()

    if janela_tutorial:
        tutorial()

    if janela_tutorial2:
        tutorial2()
    if janela_sobre_o_jogo:
        sobre_o_jogo()
    if janela_preparar3:
        preparar3()
    for events in pygame.event.get():
        if events.type == pygame.QUIT:
            abrir = False

        if events.type == pygame.KEYDOWN:
            if events.key == pygame.K_ESCAPE:
                abrir = False
        # EVENTOS DE MOUSE
        if events.type == pygame.MOUSEBUTTONDOWN:
            posicaoMouse = pygame.mouse.get_pos()
            if (config_bt.collidepoint(posicaoMouse)) and janela1:
                janela1 = False
                janela2 = True

            elif (config_btc.collidepoint(posicaoMouse)) and janela1:
                janela1 = False
                janela_configuracoes = True


            elif (config_seta.collidepoint(posicaoMouse)) and janela2:
                janela2 = False
                janela3 = True
            elif (config_seta2.collidepoint(posicaoMouse)) and janela3:
                janela3 = False
                janela4 = True
            elif (config_seta3.collidepoint(posicaoMouse)) and janela4:
                janela4 = False
                janela5 = True
            elif (config_voltar.collidepoint(posicaoMouse)) and janela5:
                janela5 = False
                janela4 = True
            elif (config_voltar2.collidepoint(posicaoMouse)) and janela4:
                janela4 = False
                janela3 = True
            elif (config_entrar.collidepoint(posicaoMouse)) and janela3:
                janela3 = False
                janela_preparar = True
            elif (config_entrar.collidepoint(posicaoMouse)) and janela4 and dsbq_fase2:
                janela4 = False
                janela_preparar2 = True
            elif (config_seta_preparar.collidepoint(posicaoMouse)) and janela_preparar:
                janela_preparar = False
                janela3 = True
            elif (config_seta_preparar.collidepoint(posicaoMouse)) and janela_preparar2:
                janela_preparar2 = False
                janela3 = True

            elif (config_entrar.collidepoint(posicaoMouse)) and janela5 and dsbq_fase3:
                janela5 = False
                janela_preparar3 = True

            elif (config_seta_preparar.collidepoint(posicaoMouse)) and janela_preparar3:
                janela_preparar3 = False
                janela3 = True





            elif (config_seta_credito2.collidepoint(posicaoMouse)) and janela_credito2:
                janela_credito2 = False
                janela_credito = True


            elif (config_x4.collidepoint(posicaoMouse)) and janela_credito2:
                janela_credito2 = False
                janela_configuracoes = True





            elif (config_bt_x5.collidepoint(posicaoMouse)) and janela_configuracoes:
                janela_tutorial = False
                janela_configuracoes = True


            elif (config_seta_tutorial.collidepoint(posicaoMouse)) and janela_configuracoes:
                janela_tutorial = False
                janela_tutorial2 = True






            elif (config_play.collidepoint(posicaoMouse)) and janela_preparar:
                janela_preparar = False
                muda_contador = True
                resposta = ["Li", "Na", "K", "Rb", "Cs", "Fr"]
                janela_contagem3 = True
                pega_tempo_inicial = False
                clicou = []
                botao_c = []
                cor = []
                contagem = 0
                for i in range(118):
                    cor_elementos = "gray"
                    cor.append(cor_elementos)
                if not pega_tempo_inicial:
                    tempo_inicial = pygame.time.get_ticks()
                    pega_tempo_inicial = True
                    print(tempo_atual - tempo_inicial)
            elif (config_play2.collidepoint(posicaoMouse)) and janela_preparar2:
                janela_preparar2 = False
                muda_contador = True
                resposta = ["F"]

                pega_tempo_inicial = False
                clicou = []
                botao_c = []
                cor = []
                contagem = 0
                janela_contagem4 = True
                for i in range(118):
                    cor_elementos = "gray"
                    cor.append(cor_elementos)
                if not pega_tempo_inicial:
                    tempo_inicial = pygame.time.get_ticks()
                    pega_tempo_inicial = True
                    print(tempo_atual - tempo_inicial)


            elif (config_play3.collidepoint(posicaoMouse)) and janela_preparar3:
                janela_preparar3 = False
                muda_contador = True
                resposta = ["Zn"]
                pega_tempo_inicial = False
                clicou = []
                botao_c = []
                cor = []
                contagem = 0
                janela_contagem5 = True

                for i in range(118):
                    cor_elementos = "gray"
                    cor.append(cor_elementos)
                if not pega_tempo_inicial:
                    tempo_inicial = pygame.time.get_ticks()
                    pega_tempo_inicial = True
                    print(tempo_atual - tempo_inicial)





            elif (config_entrar.collidepoint(posicaoMouse)) and janela5:
                if not dsbq_fase3:
                    janela5 = False
                    img_erro2 = True
                else:
                    janela5 = False
                    janela_preparar3 = True
                    contador_acertos = 0
                    contador_erros = 0
            elif (config_entrar.collidepoint(posicaoMouse)) and janela4:
                if not dsbq_fase2:
                    janela4 = False
                    img_erro = True
                else:
                    janela4 = False
                    janela_preparar2 = True
                    contador_acertos = 0
                    contador_erros = 0
            elif (config_entrar.collidepoint(posicaoMouse)) and janela5:
                if not dsbq_fase3:
                    janela5 = False
                    img_erro2 = True
                else:
                    janela5 = False
                    janela_preparar3 = True
                    contador_acertos = 0
                    contador_erros = 0



            elif (config_x2.collidepoint(posicaoMouse)) and img_erro2:

                img_erro2 = False
                janela5 = True

            elif (config_x.collidepoint(posicaoMouse)) and img_erro:

                img_erro = False
                janela4 = True

            elif (config_credito.collidepoint(posicaoMouse)) and janela_configuracoes:

                janela_configuracoes = False
                janela_credito = True

            elif (config_x3.collidepoint(posicaoMouse)) and janela_credito:

                janela_credito = False
                janela_configuracoes = True


            elif (config_seta_credito.collidepoint(posicaoMouse)) and janela_credito:

                janela_credito = False
                janela_credito2 = True



            elif (config_tutorial.collidepoint(posicaoMouse)) and janela_configuracoes:

                janela_configuracoes = False
                janela_tutorial = True





            elif (config_bt_x5.collidepoint(posicaoMouse)) and janela_tutorial:

                janela_tutorial = False
                janela_configuracoes = True




            elif (config_seta_tutorial.collidepoint(posicaoMouse)) and janela_tutorial:

                janela_tutorial = False
                janela_tutorial2 = True


            elif (config_x6.collidepoint(posicaoMouse)) and janela_tutorial2:

                janela_tutorial2 = False
                janela_configuracoes = True




            elif (config_seta_tutorial2.collidepoint(posicaoMouse)) and janela_tutorial2:

                janela_tutorial2 = False
                janela_tutorial = True


            elif (config_sobre_o_jogo.collidepoint(posicaoMouse)) and janela_configuracoes:

                janela_configuracoes = False
                janela_sobre_o_jogo = True



            elif (config_x7.collidepoint(posicaoMouse)) and janela_sobre_o_jogo:

                janela_sobre_o_jogo = False
                janela_configuracoes = True
                contador_acertos = 0
                contador_erros = 0
                acertos = 0

            elif (config_fase_dsbq.collidepoint(posicaoMouse)) and janela_parabens:
                contador_acertos = 0
                contador_erros = 0
                janela_parabens = False
                janela4 = True
                img_erro = False
                img_erro2 = False


            elif (config_refazer.collidepoint(posicaoMouse)) and janela_perdeu:

                janela_perdeu = False

                if fase_anterior == 3:

                    janela_preparar3 = True

                elif fase_anterior == 2:

                    janela_preparar2 = True

                elif fase_anterior == 1:

                    janela_preparar = True

                tick_cronometro = 0

                frame_cronometro = 0

                contador_acertos = 0

                contador_erros = 0

                resposta = ["Li", "Na", "K", "Rb", "Cs", "Fr"]


            elif (config_seta_questao2.collidepoint(posicaoMouse)) and janela_questao and passar_questao:

                passar_questao = False
                janela_questao = False
                resposta = ["C", "N", "O", "F", "P", "S", "I", "Se", "At", "Cl", "Br"]
                tick_cronometro = 0
                frame_cronometro = 0
                janela_questao2 = True
                janela_contagem3 = False
                pega_tempo_inicial = False
                muda_contador = True
                clicou = []
                botao_c = []
                cor = []
                for i in range(118):
                    cor_elementos = "gray"
                    cor.append(cor_elementos)

                if not pega_tempo_inicial:
                    tempo_inicial = pygame.time.get_ticks()
                    pega_tempo_inicial = True
                    print(tempo_atual - tempo_inicial)
            elif (config_seta_questao2.collidepoint(posicaoMouse)) and janela_questao2 and passar_questao:
                passar_questao = False
                janela_questao2 = False
                resposta = ["O", "S", "Se", "Te", "Po", "Lv"]
                janela_questao3 = True
                janela_contagem3 = False
                tick_cronometro = 0
                frame_cronometro = 0

                pega_tempo_inicial = False
                muda_contador = True
                clicou = []
                botao_c = []
                cor = []
                for i in range(118):
                    cor_elementos = "gray"
                    cor.append(cor_elementos)

                if not pega_tempo_inicial:
                    tempo_inicial = pygame.time.get_ticks()
                    pega_tempo_inicial = True
                    print(tempo_atual - tempo_inicial)

            elif (config_seta_questao2.collidepoint(posicaoMouse)) and janela_questao3 and passar_questao:

                passar_questao = False
                janela_questao3 = False
                resposta = ["F", "Cl", "I", "Br", "At", "Ts"]
                tick_cronometro = 0
                frame_cronometro = 0

                janela_questao4 = True
                pega_tempo_inicial = False
                muda_contador = True
                clicou = []
                botao_c = []
                cor = []
                for i in range(118):
                    cor_elementos = "gray"
                    cor.append(cor_elementos)

                if not pega_tempo_inicial:
                    tempo_inicial = pygame.time.get_ticks()
                    pega_tempo_inicial = True
                    print(tempo_atual - tempo_inicial)
            elif (config_seta_questao2.collidepoint(posicaoMouse)) and janela_questao4 and passar_questao:
                passar_questao = False
                janela_questao4 = False
                resposta = ["H"]
                tick_cronometro = 0
                frame_cronometro = 0

                janela_questao5 = True
                pega_tempo_inicial = False
                muda_contador = True
                clicou = []
                botao_c = []
                cor = []
                for i in range(118):
                    cor_elementos = "gray"
                    cor.append(cor_elementos)

                if not pega_tempo_inicial:
                    tempo_inicial = pygame.time.get_ticks()
                    pega_tempo_inicial = True
                    print(tempo_atual - tempo_inicial)

            elif (config_seta_questao2.collidepoint(posicaoMouse)) and janela_questao1_fase2 and passar_questao:

                passar_questao = False
                janela_questao1_fase2 = False
                resposta = ["Fr"]
                tick_cronometro = 0
                frame_cronometro = 0

                janela_questao2_fase2 = True
                janela_contagem4 = False
                pega_tempo_inicial = False
                muda_contador = True
                clicou = []
                botao_c = []
                cor = []
                for i in range(118):
                    cor_elementos = "gray"
                    cor.append(cor_elementos)

                if not pega_tempo_inicial:
                    tempo_inicial = pygame.time.get_ticks()
                    pega_tempo_inicial = True
                    print(tempo_atual - tempo_inicial)
            elif (config_seta_questao2.collidepoint(posicaoMouse)) and janela_questao2_fase2 and passar_questao:
                passar_questao = False
                janela_questao2_fase2 = False
                resposta = ["He"]
                tick_cronometro = 0
                frame_cronometro = 0
                janela_questao3_fase2 = True
                janela_contagem4 = False

                pega_tempo_inicial = False
                muda_contador = True
                clicou = []
                botao_c = []
                cor = []
                for i in range(118):
                    cor_elementos = "gray"
                    cor.append(cor_elementos)

                if not pega_tempo_inicial:
                    tempo_inicial = pygame.time.get_ticks()
                    pega_tempo_inicial = True
                    print(tempo_atual - tempo_inicial)

            elif (config_seta_questao2.collidepoint(posicaoMouse)) and janela_questao3_fase2 and passar_questao:

                passar_questao = False
                janela_questao3_fase2 = False
                resposta = ["Ca"]
                tick_cronometro = 0
                frame_cronometro = 0

                janela_questao4_fase2 = True
                pega_tempo_inicial = False
                muda_contador = True
                clicou = []
                botao_c = []
                cor = []
                for i in range(118):
                    cor_elementos = "gray"
                    cor.append(cor_elementos)

                if not pega_tempo_inicial:
                    tempo_inicial = pygame.time.get_ticks()
                    pega_tempo_inicial = True
                    print(tempo_atual - tempo_inicial)
            elif (config_seta_questao2.collidepoint(posicaoMouse)) and janela_questao4_fase2 and passar_questao:
                passar_questao = False
                janela_questao4_fase2 = False
                resposta = ["Au"]
                tick_cronometro = 0
                frame_cronometro = 0

                janela_questao5_fase2 = True
                pega_tempo_inicial = False
                muda_contador = True
                clicou = []
                botao_c = []
                cor = []
                for i in range(118):
                    cor_elementos = "gray"
                    cor.append(cor_elementos)

                if not pega_tempo_inicial:
                    tempo_inicial = pygame.time.get_ticks()
                    pega_tempo_inicial = True
                    print(tempo_atual - tempo_inicial)
            elif (config_seta_questao2.collidepoint(posicaoMouse)) and janela_questao1_fase3 and passar_questao:

                passar_questao = False
                janela_questao1_fase3 = False
                resposta = ["Cr"]
                tick_cronometro = 0
                frame_cronometro = 0

                janela_questao2_fase3 = True
                janela_contagem5 = False
                pega_tempo_inicial = False
                muda_contador = True
                clicou = []
                botao_c = []
                cor = []
                for i in range(118):
                    cor_elementos = "gray"
                    cor.append(cor_elementos)

                if not pega_tempo_inicial:
                    tempo_inicial = pygame.time.get_ticks()
                    pega_tempo_inicial = True
                    print(tempo_atual - tempo_inicial)
            elif (config_seta_questao2.collidepoint(posicaoMouse)) and janela_questao2_fase3 and passar_questao:
                passar_questao = False
                janela_questao2_fase3 = False
                resposta = ["Ca"]
                tick_cronometro = 0
                frame_cronometro = 0
                janela_questao3_fase3 = True
                janela_contagem5 = False

                pega_tempo_inicial = False
                muda_contador = True
                clicou = []
                botao_c = []
                cor = []
                for i in range(118):
                    cor_elementos = "gray"
                    cor.append(cor_elementos)

                if not pega_tempo_inicial:
                    tempo_inicial = pygame.time.get_ticks()
                    pega_tempo_inicial = True
                    print(tempo_atual - tempo_inicial)

            elif (config_seta_questao2.collidepoint(posicaoMouse)) and janela_questao3_fase3 and passar_questao:

                passar_questao = False
                janela_questao3_fase3 = False
                resposta = ["Fe"]
                tick_cronometro = 0
                frame_cronometro = 0

                janela_questao4_fase3 = True
                pega_tempo_inicial = False
                muda_contador = True
                clicou = []
                botao_c = []
                cor = []
                for i in range(118):
                    cor_elementos = "gray"
                    cor.append(cor_elementos)

                if not pega_tempo_inicial:
                    tempo_inicial = pygame.time.get_ticks()
                    pega_tempo_inicial = True
                    print(tempo_atual - tempo_inicial)
            elif (config_seta_questao2.collidepoint(posicaoMouse)) and janela_questao4_fase3 and passar_questao:
                passar_questao = False
                janela_questao4_fase3 = False
                resposta = ["Ar"]
                tick_cronometro = 0
                frame_cronometro = 0

                janela_questao5_fase3 = True
                pega_tempo_inicial = False
                muda_contador = True
                clicou = []
                botao_c = []
                cor = []
                for i in range(118):
                    cor_elementos = "gray"
                    cor.append(cor_elementos)

                if not pega_tempo_inicial:
                    tempo_inicial = pygame.time.get_ticks()
                    pega_tempo_inicial = True
                    print(tempo_atual - tempo_inicial)



            elif janela_questao or janela_questao2 or janela_questao3 or janela_questao4 or janela_questao5 or janela_questao1_fase2 or janela_questao2_fase2 or janela_questao3_fase2 or janela_questao4_fase2 or janela_questao5_fase2 or janela_questao1_fase3 or janela_questao2_fase3 or janela_questao3_fase3 or janela_questao4_fase3 or janela_questao5_fase3:
                if tempo_atual - tempo_inicial <= 22000:
                    for i in range(88):
                        if quadrados[i].collidepoint(posicaoMouse):
                            z = i
                            if cor[i] == "gray":
                                cor[i] = "lightblue"
                                clicou.append(elementos[i])
                                botao_c.append(i)
                                print(clicou)
                            elif cor[i] == "lightblue":
                                cor[i] = "gray"
                                clicou.remove(elementos[i])
                                botao_c.remove(i)
                                print(clicou)



                elif (config_seta_questao2.collidepoint(posicaoMouse)) and janela_questao5:
                    if contador_acertos > contador_erros:
                        janela_questao5 = False
                        janela_parabens = True
                        passar_questao = False
                        janela.blit(redms_parabens, (0, 0))
                        tick_cronometro = 0
                        frame_cronometro = 0
                        # texto_acertos1 = fonte.render(str(contador_acertos), True, "#00BF63")
                        # janela.blit(texto_acertos1, (65, 100))
                        # texto_erros1 = fonte.render(str(contador_erros), True, "green")#FF3131
                        # janela.blit(texto_erros1, (190, 100))

                        dsbq_fase2 = True
                        img_fase2 = pygame.image.load("QUIZ PERIÓDICO/12.png")
                        redmsF2 = pygame.transform.scale(img_fase2, (largura, altura))
                        resposta = ""



                    elif contador_erros > contador_acertos:
                        fase_anterior = 1
                        passar_questao = False


                        janela_questao5 = False
                        janela_perdeu = True


                elif (config_seta_questao2.collidepoint(posicaoMouse)) and janela_questao5_fase2:
                    if contador_acertos > contador_erros:
                        janela_questao5_fase2 = False
                        janela_parabens = True
                        passar_questao = False
                        janela.blit(redms_parabens, (0, 0))
                        tick_cronometro = 0
                        frame_cronometro = 0
                        texto_acertos = fonte.render(str(contador_acertos), True, "#00BF63")
                        janela.blit(texto_acertos, (65, 60))
                        texto_erros = fonte.render(str(contador_erros), True, "#FF3131")
                        janela.blit(texto_erros, (190, 60))

                        dsbq_fase3 = True
                        img_fase3 = pygame.image.load("QUIZ PERIÓDICO/13.png")
                        redmsF3 = pygame.transform.scale(img_fase3, (largura, altura))
                        resposta = ""

                    elif contador_erros > contador_acertos:
                        fase_anterior = 2
                        janela_questao5_fase2 = False
                        passar_questao = False

                        janela_perdeu = True
                elif (config_seta_questao2.collidepoint(posicaoMouse)) and janela_questao5_fase3:
                    if contador_acertos > contador_erros:
                        janela_questao5_fase3 = False
                        janela_parabens = True
                        tick_cronometro = 0
                        passar_questao = False
                        frame_cronometro = 0
                        janela.blit(redms_parabens, (0, 0))
                        texto_acertos = fonte.render(str(contador_acertos), True, "#00BF63")
                        janela.blit(texto_acertos, (65, 60))
                        texto_erros = fonte.render(str(contador_erros), True, "#FF3131")
                        janela.blit(texto_erros, (190, 60))

                    elif contador_erros > contador_acertos:
                        fase_anterior = 3
                        passar_questao = False
                        janela_questao5_fase3 = False
                        janela_perdeu = True



                elif (config_seta_questao2.collidepoint(posicaoMouse)) and dsbq_fase2:
                    if contador_acertos > contador_erros:
                        janela_questao5 = False
                        janela_parabens = True
                        dsbq_fase3 = True
                        img_fase3 = pygame.image.load("Slide do Jogo ( Bagunçado )/33.png")
                        redmsF3 = pygame.transform.scale(img_fase3, (largura, altura))

                        resposta = ""
                    elif contador_erros > contador_acertos:
                        janela_questao5 = False
                        janela_perdeu = True
            if janela2 or janela3 or janela4 or janela5 or janela_configuracoes:
                if (config_casa.collidepoint(posicaoMouse)):
                    janela2 = False
                    janela3 = False
                    janela4 = False
                    janela5 = False
                    janela_configuracoes = False
                    janela_preparar = False
                    janela_contagem3 = False

                    janela1 = True
    if janela_questao5 or janela_questao4 or janela_questao3 or janela_questao2 or janela_questao or janela_questao5_fase2 or janela_questao4_fase2 or janela_questao3_fase2 or janela_questao2_fase2 or janela_questao1_fase2 or janela_questao5_fase3 or janela_questao4_fase3 or janela_questao3_fase3 or janela_questao2_fase3 or janela_questao1_fase3:
        if tempo_atual - tempo_inicial >= 22000:
            acertos = 0
            passar_questao = True

            # font = pygame.font.SysFont(None, 20)  # Escolha a fonte aqui
            # texttempo = font.render(str(tempo_atual), True, (0, 0, 0))  # Define a cor do texto aqui
            #
            # janela.blit(texttempo, (20,20))


            for i in range(len(clicou)):

                if clicou[i] in resposta:
                    cor[botao_c[i]] = "lightgreen"
                elif clicou[i] not in resposta:
                    cor[botao_c[i]] = "red"
                if clicou[i] in resposta:
                    acertos += 1
            for i in range(len(resposta)):
                if resposta[i] not in clicou:
                    print(resposta[i])
                    for o in range(len(elementos)):
                        if resposta[i] == elementos[o]:
                            cor[o] = "yellow"

            if muda_contador:
                if len(clicou) == len(resposta):
                    if acertos == len(resposta):
                        contador_acertos += 1

                    else:
                        contador_erros += 1
                else:
                    contador_erros += 1

            muda_contador = False

    pygame.display.update()
